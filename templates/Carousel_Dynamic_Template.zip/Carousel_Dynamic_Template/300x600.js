(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Carousel_Image = function() {
	this.initialize(img.Carousel_Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,200,200);


(lib.Logo = function() {
	this.initialize(img.Logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,916,200);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tagline = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1C1F").s().p("AggAsIAAgCQAFgCABgEQABgDAAgOIAAgZQAAgMgBgDQgBgCgGgCIAAgCIAfgQIAAAUIACgDIANgNQAGgDAFAAQAKAAAAAIQAAAGgDADQgDACgEAAQgEAAgEgDQgEgDgBAAQgEAAgHAHIgCADIAAAmQAAAOABADQABAEAFACIAAACg");
	this.shape.setTransform(65.275,1.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1F1C1F").s().p("AgXAiQgOgMAAgWQAAgUAOgNQAMgLANAAQAPAAAKAIQAKAJABAPIg0AAIAAAKQAAApAaAAQAMAAAKgHIACACQgNALgRAAQgRAAgMgLgAARgPQgCgagNAAQgNAAgDAaIAfAAIAAAAg");
	this.shape_1.setTransform(56.875,1.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1F1C1F").s().p("AASArIgQguIgTAuIgGAAIgZhAIgHgPQgBgDgDgBIAAgCIAjAAIAAACQgEABgBADQAAAEAEALIAPAnIAKgaIgDgNIgHgPQgBgDgDgBIAAgCIAiAAIAAACQgFABAAADQgBAEADALIAOAlIANghQAEgNgBgFQgCgEgGgBIAAgCIAVAAIAAACQgDABgCAEQgDAEgFAOIgWA8g");
	this.shape_2.setTransform(45.975,1.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1F1C1F").s().p("AgaAiQgQgMAAgWQAAgUAQgNQAMgKAOAAQAPAAAMAKQAQANAAAUQAAAWgQAMQgMAKgPAAQgOAAgMgKgAgSAAQAAAqASAAQAUAAgBgqQABgogUAAQgSAAAAAog");
	this.shape_3.setTransform(34.6,1.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1F1C1F").s().p("AgzBDIAAgCQAHgBABgHQACgGAAgZIAAgyQAAgagCgHQgBgFgHgCIAAgDIAzAAQA0AAAAAiQAAATgPAKQgOAJgXAAIgPAAIAAAVQAAAZABAGQACAHAHABIAAACgAgPACIAPAAQAOABAGgIQAHgHAAgTQAAgggbAAIgPAAg");
	this.shape_4.setTransform(23.975,-0.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1F1C1F").s().p("AgPApIgIgDQgBAAAAAAQgBAAAAABQgBAAAAABQAAAAAAABIgDAAIAAgZIACAAQAIAaATAAQAQAAAAgPQAAgGgEgEQgFgEgKgEQgOgFgFgFQgGgHAAgLQAAgKAHgHQAIgHALAAQAGAAAGACIAIACQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIADAAIAAAXIgDAAQgFgVgSAAQgOAAAAAMQAAAFAFAFQAEACAKAEQAQAGAFAGQAGAGAAAMQAAALgJAIQgJAHgMAAQgIAAgHgDg");
	this.shape_5.setTransform(10.625,1.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1F1C1F").s().p("AgRA+IAAgDQAFgBABgEQABgDAAgPIAAgZQAAgMgBgCQgBgDgGgBIAAgDIAdgQIAAA+QAAAPABADQACAEAFABIAAADgAgIgnQgEgEAAgFQAAgFAEgEQAEgEAEAAQAGAAADAEQAEADgBAFQABAGgEAEQgDADgGAAQgEAAgEgDg");
	this.shape_6.setTransform(4.35,-0.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1F1C1F").s().p("AgKA3QgGgGAAgKIAAg+IgIAAIAAgCQAJgBAHgJQAIgKACgOIADAAIAAAhIASAAIAAADIgSAAIAAA7QAAALACAEQACAEAFAAQAGAAADgEIACACQgGAHgNAAQgLAAgFgFg");
	this.shape_7.setTransform(-4.9,0.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1F1C1F").s().p("AggAsIAAgCQAFgCABgEQABgDAAgOIAAgZQAAgMgBgDQgBgCgGgCIAAgCIAfgQIAAAUIACgDIANgNQAGgDAFAAQAKAAAAAIQAAAGgDADQgDACgEAAQgEAAgEgDQgEgDgBAAQgEAAgHAHIgCADIAAAmQAAAOABADQABAEAFACIAAACg");
	this.shape_8.setTransform(-11.925,1.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1F1C1F").s().p("AgaAiQgQgMAAgWQAAgUAQgNQAMgKAOAAQAPAAANAKQAPANAAAUQAAAWgPAMQgNAKgPAAQgOAAgMgKgAgSAAQAAAqASAAQAUAAgBgqQABgogUAAQgSAAAAAog");
	this.shape_9.setTransform(-20.85,1.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1F1C1F").s().p("AgcBFIAAgCQAFgCABgEQABgDAAgOIAAg4IgKAAIAAgCQAGgBACgDQACgCAAgEIAAgNQAAgQALgIQAIgHAMAAQAKAAAGADQAGAEAAAGQAAAGgIAAQgEAAgCgCQgCgBgBgFQgBgIgFAAQgJAAAAAVIAAAdIASAAIAAADIgSAAIAAA4QAAAOACADQACAEAIACIAAACg");
	this.shape_10.setTransform(-28.225,-0.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1F1C1F").s().p("AAhAsIAAgCQAFgCABgEQACgEAAgNIAAgrQAAgKgIAAQgGAAgLALIgEADIAAAnQAAAOABADQABAEAFACIAAACIglAAIAAgCQAFgCACgEQABgEABgNIAAgrQgBgKgHAAQgHAAgLALIgDADIAAAnQAAAOABADQABAEAGACIAAACIgmAAIAAgCQAFgCABgEQABgDAAgOIAAgZQAAgMgBgDQgBgCgGgCIAAgCIAfgQIAAATIADgDQAIgIAGgDQAGgEAIAAQAQAAACASIAFgDQAHgIAFgDQAIgEAHAAQAUAAAAAYIAAAlQAAAOABADQABAEAFACIAAACg");
	this.shape_11.setTransform(-39.55,1.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1F1C1F").s().p("AgaAiQgPgMgBgWQABgUAPgNQANgKANAAQAPAAAMAKQAPANABAUQgBAWgPAMQgMAKgPAAQgNAAgNgKgAgSAAQAAAqASAAQATAAAAgqQAAgogTAAQgSAAAAAog");
	this.shape_12.setTransform(-52.05,1.725);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1F1C1F").s().p("AgiA0QgTgUAAggQAAggAVgUQASgRAYAAQALAAAJADQAKAEACAAQAFAAACgFIADAAIAAAhIgDAAQgLgggcAAQgPAAgKAPQgJAQgBAhQAABCAqAAQAVAAAOgQIACACQgPAUgcAAQgaAAgTgSg");
	this.shape_13.setTransform(-63.3,-0.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Tagline, new cjs.Rectangle(-71.4,-11,142.9,22), null);


(lib.Logo_Lockup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Logo();
	this.instance.setTransform(-91.65,-20,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Logo_Lockup, new cjs.Rectangle(-91.6,-20,183.2,40), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1F1C1F").ss(1.3,2,1).p("AnMAAIOZAA");
	this.shape.setTransform(150,574.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1F1C1F").s().p("AgTAWQgIgIgBgOQAAgNAJgJQAIgIALAAQAOAAAHAIQAIAIAAAOIgBADIgpAAQAAAHAEAEQAFAFAGAAQAKAAAEgKIALADQgCAIgHAGQgHAFgJAAQgMAAgJgJgAAOgGQAAgFgDgEQgEgDgHAAQgFAAgFADQgDAEAAAFIAbAAIAAAAg");
	this.shape_1.setTransform(192.95,561.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1F1C1F").s().p("AgGAdIgYg5IAQAAIAPApIAOgpIAPAAIgWA5g");
	this.shape_2.setTransform(186.05,561.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1F1C1F").s().p("AgVAWQgIgJAAgNQAAgMAIgKQAJgIAMAAQANAAAJAIQAIAKAAAMQAAANgIAJQgJAJgNAAQgMAAgJgJgAgKgNQgFAFAAAIQAAAIAFAFQAEAGAGAAQAHAAAEgGQAFgFAAgIQAAgIgFgFQgEgFgHABQgGgBgEAFg");
	this.shape_3.setTransform(178.975,561.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1F1C1F").s().p("AgaArIAAhVIAPAAIAABHIAmAAIAAAOg");
	this.shape_4.setTransform(172.025,560.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1F1C1F").s().p("AgVAjQgHgIgBgOQABgMAHgIQAIgJAMAAQANAAADAIIAAgjIAOAAIAABLIABALIgOAAIgBgIQgEAJgMAAQgMAAgIgJgAgKAAQgFAFABAIQAAAJADAFQAFAFAGAAQAHAAAEgFQAEgFAAgJQAAgIgDgFQgFgEgHAAQgGAAgEAEg");
	this.shape_5.setTransform(164.05,560.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1F1C1F").s().p("AgQAeIAAg6IAOAAIAAAJQADgKANABIADAAIAAAOIgEAAQgPAAAAAPIAAAdg");
	this.shape_6.setTransform(158.2,561.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1F1C1F").s().p("AgGAsIAAg5IANAAIAAA5gAgFgcQgDgCAAgEQAAgDADgDQACgDADAAQADAAADADQADADAAADQAAAEgDACQgDADgDAAQgDAAgCgDg");
	this.shape_7.setTransform(153.55,559.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1F1C1F").s().p("AAMAsIAAgjQAAgMgMAAQgFAAgDADQgDADAAAGIAAAjIgOAAIAAhWIAOAAIAAAiQAGgIAKABQAKAAAFAGQAGAHAAAIIAAAmg");
	this.shape_8.setTransform(148.1,560);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1F1C1F").s().p("AgGArIAAhHIgcAAIAAgOIBFAAIAAAOIgcAAIAABHg");
	this.shape_9.setTransform(140.5,560.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1F1C1F").s().p("AgcApIAAhQIANAAIAAAIQACgEAFgDQAFgCAFAAQANgBAHAKQAIAIgBANQAAANgHAIQgIAJgMAAQgLAAgGgIIAAAdgAgKgXQgFAFAAAIQAAAIAFAFQAEAEAGAAQAHAAAEgEQAFgFAAgIQAAgIgFgFQgEgFgHAAQgGAAgEAFg");
	this.shape_10.setTransform(129.55,562.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1F1C1F").s().p("AgVAWQgIgJAAgNQAAgMAIgKQAJgIAMAAQANAAAJAIQAIAKAAAMQAAANgIAJQgJAJgNAAQgMAAgJgJgAgKgNQgFAFAAAIQAAAIAFAFQAEAGAGAAQAHAAAEgGQAFgFAAgIQAAgIgFgFQgEgFgHABQgGgBgEAFg");
	this.shape_11.setTransform(121.775,561.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1F1C1F").s().p("AAMAsIAAgjQAAgMgMAAQgFAAgDADQgDADAAAGIAAAjIgOAAIAAhWIAOAAIAAAiQAGgIAKABQAKAAAFAGQAGAHAAAIIAAAmg");
	this.shape_12.setTransform(114.45,560);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1F1C1F").s().p("AgWAkQgHgHgCgLIAOgEQAAAIAFAEQAGAGAIgBQAHABAEgEQAEgEAAgFQAAgJgMgCIgLgDQgKgCgFgEQgGgHAAgJQAAgLAJgHQAIgJALABQAOAAAHAHQAHAGABAIIgMAFQgBgGgEgDQgEgFgIAAQgFAAgEAEQgFADAAAGQABAIAJADIAMACQAKACAHAGQAFAGAAAKQAAAKgHAIQgJAHgNABQgOAAgKgJg");
	this.shape_13.setTransform(106.85,560.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(101.2,550.4,97.60000000000001,25), null);


(lib.Text_Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Description
	this.description = new cjs.Text("Try it: every day, yoga, dog \nwalking, extreme brunching.", "11px 'Circular Std Book'", "#1F1C20");
	this.description.name = "description";
	this.description.textAlign = "center";
	this.description.lineHeight = 14;
	this.description.lineWidth = 176;
	this.description.parent = this;
	this.description.setTransform(150.15,407.2);

	this.timeline.addTween(cjs.Tween.get(this.description).wait(1));

	// Title
	this.title = new cjs.Text("Low impact. Colorful, minimalist \nstyles that flow with intention.", "14px 'Circular Std Book'", "#1F1C1F");
	this.title.name = "title";
	this.title.textAlign = "center";
	this.title.lineHeight = 18;
	this.title.lineWidth = 226;
	this.title.parent = this;
	this.title.setTransform(150.05,352.95);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Text_Container, new cjs.Rectangle(35.2,351,229.8,86), null);


(lib.Image_Placeholder = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Carousel_Image();
	this.instance.setTransform(0,0,0.8,1.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_Placeholder, new cjs.Rectangle(0,0,160,250), null);


(lib.CarouselDot = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {normal:0,active:1};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgiAjQgPgPAAgUQAAgUAPgPQAPgOATAAQAVAAAOAOQAPAPAAAUQAAAUgPAPQgOAPgVAAQgTAAgPgPg");
	this.shape.setTransform(5,5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DDC1AA").s().p("AgiAjQgPgPAAgUQAAgUAPgPQAPgOATAAQAVAAAOAOQAPAPAAAUQAAAUgPAPQgOAPgVAAQgTAAgPgPg");
	this.shape_1.setTransform(5,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,10,10);


(lib.Background = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Carousel_Image();
	this.instance.setTransform(0,0,1.5,2.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Background, new cjs.Rectangle(0,0,300,500), null);


(lib.Logo_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Lockup
	this.instance = new lib.Logo_Lockup();
	this.instance.setTransform(0,0.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},12).wait(30));

	// Tagline_Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ar9D0IAAkAIX7AAIAAEAg");
	mask.setTransform(0.025,24.4);

	// Tagline
	this.instance_1 = new lib.Tagline();
	this.instance_1.setTransform(-0.1,6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(12).to({_off:false},0).to({y:35.9},12,cjs.Ease.quadOut).wait(18));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.6,-19.8,183.2,66.7);


(lib.Carousel_Image_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TRANSFORM_ONLY
	this.placeholder = new lib.Image_Placeholder();
	this.placeholder.name = "placeholder";
	this.placeholder.setTransform(150,162.5,1.875,1.3,0,0,0,80,125);

	this.timeline.addTween(cjs.Tween.get(this.placeholder).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Carousel_Image_1, new cjs.Rectangle(0,0,300,325), null);


(lib.Carousel_Dots = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// DO_NOT_EDIT_HERE
	this.instance = new lib.CarouselDot();
	this.instance.setTransform(-5,15);

	this.instance_1 = new lib.CarouselDot();
	this.instance_1.setTransform(15,-5);

	this.instance_2 = new lib.CarouselDot();
	this.instance_2.setTransform(-25,-5);

	this.instance_3 = new lib.CarouselDot();
	this.instance_3.setTransform(-5,-5);

	this.instance_4 = new lib.CarouselDot();
	this.instance_4.setTransform(-5,-25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Carousel_Dots, new cjs.Rectangle(-57.2,-58,114.4,83), null);


(lib.Logo_Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.instance = new lib.Logo_1("synched",0,false);
	this.instance.setTransform(0,-13.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(52).to({startPosition:41},0).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.6,-33.7,183.2,66.7);


(lib.Image_Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// DO_NOT_EDIT_HERE
	this.image = new lib.Carousel_Image_1();
	this.image.name = "image";
	this.image.setTransform(100,100,1,1,0,0,0,100,100);

	this.timeline.addTween(cjs.Tween.get(this.image).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_Container, new cjs.Rectangle(0,0,300,325), null);


(lib.Dots_Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TRANSFORM_ONLY
	this.dots = new lib.Carousel_Dots();
	this.dots.name = "dots";

	this.timeline.addTween(cjs.Tween.get(this.dots).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Dots_Container, new cjs.Rectangle(-25,-25,50,50), null);


(lib.CarouselItem = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {enter_start:9,enter_end:19,leave_start:24,leave_end:34};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_34 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(15).call(this.frame_34).wait(1));

	// Text
	this.textContainer = new lib.Text_Container();
	this.textContainer.name = "textContainer";
	this.textContainer.setTransform(100,13.8,1,1,0,0,0,100,13.8);

	this.timeline.addTween(cjs.Tween.get(this.textContainer).wait(9).to({regX:99.8,scaleX:0.9999,x:99.8,alpha:0},0).wait(4).to({regX:100,scaleX:1,x:100,alpha:1},6,cjs.Ease.quadOut).wait(5).to({alpha:0},5,cjs.Ease.quadOut).wait(6));

	// Image
	this.imageContainer = new lib.Image_Container();
	this.imageContainer.name = "imageContainer";
	this.imageContainer.setTransform(100,100,1,1,0,0,0,100,100);

	this.timeline.addTween(cjs.Tween.get(this.imageContainer).wait(9).to({regX:99.8,scaleX:0.9999,x:-200.2},0).to({regX:100,scaleX:1,x:100},10,cjs.Ease.quadOut).wait(5).to({x:400},10,cjs.Ease.quadOut).wait(1));

	// Visible_Area
	this.instance = new lib.Background();
	this.instance.setTransform(150,250,1,1,0,0,0,150,250);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(35));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-300,0,900,500);


(lib.Carousel_Placeholder = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// DO_NOT_EDIT_HERE
	this.instance = new lib.CarouselItem();
	this.instance.setTransform(-200,112.5,1,1,0,0,0,-200,112.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Carousel_Placeholder, new cjs.Rectangle(0,0,300,500), null);


(lib.Carousel_Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TRANSFORM_ONLY
	this.placeholder = new lib.Carousel_Placeholder();
	this.placeholder.name = "placeholder";
	this.placeholder.setTransform(100,112.5,1.0001,1,0,0,0,100,112.5);

	this.timeline.addTween(cjs.Tween.get(this.placeholder).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Carousel_Container, new cjs.Rectangle(0,0,300,500), null);


// stage content:
(lib._300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {carousel_load:0,carousel_play:77};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,77];
	// timeline functions:
	this.frame_0 = function() {
		/**
		 * Set up and load carousel assets,
		 * should be positioned in the first frame
		 */
		var _this = this;
		if (this.carousel && this.loader) {
			this.carousel.reset();
			return;
		}
		
		/** Path/URL to JSON file */
		var json = 'data/campaign.json';
		
		/** Carousel settings */
		var settings = {
			/** Number of times the carousel should loop */
			repeats: 2,
		
			/** Max items to show, set to null to show all */
			maxItems: 4,
		
			/** Shuffle order of items */
			randomizeItems: true,
		
			/** Number of milliseconds to show each item */
			activeItemDuration: 2000,
		
			/** Animate first item on start */
			animateOnStart: false,
		
			/**
			 * Image vertical alignment
			 * @type {'top'|'middle'|'bottom'}
			 */
			imageAlignmentY: 'middle',
		
			/**
			 * Image vertical alignment
			 * @type {'left'|'center'|'right'}
			 */
			imageAlignmentX: 'center',
		
			/**
			 * Image size
			 * @type {'fill'|'fit'|'stretch'}
			 */
			imageSize: 'fit',
		
			/**
			 * Direction of the dot
			 * @type {'horizontal'|'vertical'}
			 */
			dotsDirection: 'horizontal',
		
			/** Height of a single dot, must match Carousel_Dot symbol */
			dotHeight: 10,
		
			/** Width of a single dot, must match Carousel_Dot symbol */
			dotWidth: 10,
		
			/** Space between dots */
			dotGap: 10,
		};
		
		/** Logger object */
		var Logger = {
			/** Enable/disable logging, set to false on production */
			enabled: true,
			info: function () {
				if (!this.enabled) return;
				console.log.apply(console, arguments);
			},
			time: function () {
				if (!this.enabled) return;
				console.time.apply(console, arguments);
			},
			timeEnd: function () {
				if (!this.enabled) return;
				console.timeEnd.apply(console, arguments);
			},
		};
		
		/** Helper functions */
		var Utils = {
			scale: function (container, image, mode) {
				switch (mode) {
					case 'stretch':
						return { x: container.width / image.width, y: container.height / image.height };
					case 'fill':
						var s = Math.max(container.height / image.height, container.width / image.width);
						return { x: s, y: s };
					case 'fit':
						var l = image.width > image.height ? 'width' : 'height';
						var s = container[l] / image[l];
						return { x: s, y: s };
				}
			},
			alignY: function (container, image, anchor, scale) {
				scale = isNaN(scale) ? 1 : scale;
				if (anchor === 'top') return container.y;
				if (anchor === 'bottom') return container.y + container.height - image.height * scale;
				if (anchor === 'middle') return container.y + (container.height - image.height * scale) / 2;
			},
			alignX: function (container, image, anchor, scale) {
				scale = isNaN(scale) ? 1 : scale;
				if (anchor === 'left') return container.x;
				if (anchor === 'right') return container.x + container.width - image.width * scale;
				if (anchor === 'center') return container.x + (container.width - image.width * scale) / 2;
			},
			shuffle: function (array) {
				for (var i = array.length - 1; i > 0; i--) {
					var j = Math.floor(Math.random() * (i + 1));
					var temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
		
				return array;
			},
		};
		
		/**
		 * Array.prototype.forEach() polyfill
		 * @author Chris Ferdinandi
		 * @license MIT
		 */
		if (!Array.prototype.forEach) {
			Array.prototype.forEach = function (callback, thisArg) {
				thisArg = thisArg || window;
				for (var i = 0; i < this.length; i++) {
					callback.call(thisArg, this[i], i, this);
				}
			};
		}
		
		/** Carousel object */
		var carousel = new (function () {
			this._container = _this.carouselArea;
			this._dotsContainer = _this.carouselDots;
			this.bounds = this._container.placeholder.getTransformedBounds();
			this.items = [];
			this.dots = [];
		
			// Hide placeholder elements
			this._container.placeholder.visible = false;
			if (this._dotsContainer) {
				this._dotsContainer.dots.children.forEach(function (d) {
					d.visible = false;
				});
			}
		
		
			/** Add item to carousel */
			this.addItem = function (bitmap, attributes) {
				var item = new lib.CarouselItem();
				var id = this.items.push(item) - 1;
		
				item.gotoAndStop('enter');
				if (item.textContainer) {
					// Add dynamic text, access item props using the attributes object
					// Access all JSON data, using the payload object
					item.textContainer.title.text = attributes.title || '';
					item.textContainer.description.text = attributes.des || '';
				}
		
				// Adjust item size and position
				item.scaleY = this.bounds.height / item.getTransformedBounds().height;
				item.scaleX = this.bounds.width / item.getTransformedBounds().width;
				item.x = this.bounds.x;
				item.y = this.bounds.y;
		
				// Add dynamic image
				var bitmap = new createjs.Bitmap(bitmap);
				var imageBounds = item.imageContainer.image.placeholder.getTransformedBounds();
		
				// Adjust image size and position
				var imageScale = Utils.scale(imageBounds, bitmap.image, settings.imageSize);
				bitmap.x = Utils.alignX(imageBounds, bitmap.image, settings.imageAlignmentX, imageScale.x);
				bitmap.y = Utils.alignY(imageBounds, bitmap.image, settings.imageAlignmentY, imageScale.y);
				bitmap.scaleX = imageScale.x;
				bitmap.scaleY = imageScale.y;
		
				item.imageContainer.image.placeholder.visible = false;
				item.imageContainer.image.addChild(bitmap);
		
				if (this._dotsContainer) {
					// Add carousel dots
					var dot = new lib.CarouselDot();
		
					dot.cursor = 'pointer';
					dot.addEventListener('mouseover', function () {
						carousel.stop();
						carousel.seek(id);
					});
		
					this.dots.push(dot);
					this._dotsContainer.dots.addChild(dot);
		
					// Center dots
					var size = settings.dotsDirection === 'vertical' ? settings.dotHeight : settings.dotWidth;
					var totalLength = this.dots.length * size + Math.max(this.dots.length - 1, 0) * settings.dotGap;
					this.dots.forEach(function (dot, i) {
						var position = i * size + settings.dotGap * i;
						if (settings.dotsDirection === 'vertical') {
							dot.y = position - totalLength / 2;
							dot.x = new lib.CarouselDot().x - settings.dotWidth / 2;
						} else {
							dot.x = position - totalLength / 2;
							dot.y = new lib.CarouselDot().y - settings.dotHeight / 2;
						}
					});
				}
		
				_this.carouselArea.addChild(item);
			};
		
			/** Reset carousel to initial state */
			this.reset = function () {
				this.playing = false;
				this.completedPlaythroughs = 0;
				this.activeItemElapsedTicks = 0;
				this.activeItem = null;
		
				this.items.forEach(function (item, i) {
					item.gotoAndStop('enter_start');
					if (this._dotsContainer) this.dots[i].gotoAndStop('normal');
				});
		
				if (!settings.animateOnStart) {
					this.seek(0, false);
				}
			};
		
			/** Change the active item */
			this.seek = function (id, animate) {
				if (this.activeItem === id) return;
				animate = animate === undefined ? true : false;
		
				if (this.activeItem !== null) {
					if (this._dotsContainer) this.dots[this.activeItem].gotoAndStop('normal');
		
					if (animate) {
						this.items[this.activeItem].gotoAndPlay('leave_start');
					} else {
						this.items[this.activeItem].gotoAndStop('leave_end');
					}
				}
		
				this.activeItem = id;
				if (this._dotsContainer) this.dots[id].gotoAndStop('active');
		
				if (animate) {
					this.items[id].gotoAndPlay('enter_start');
				} else {
					this.items[id].gotoAndStop('enter_end');
				}
			};
		
			/** Start carousel animation */
			this.play = function () {
				// Do not autoplay if only one item
				if (this.items.length < 2) return;
		
				this.reset();
				this.playing = true;
				Logger.time('Carousel Duration');
				Logger.info('Carousel Started');
		
				_this.addEventListener('tick', function () {
					var active = carousel.items[carousel.activeItem];
					var last = carousel.items[carousel.items.length - 1];
		
					if (carousel.playing) {
						if (!active) {
							carousel.seek(0);
							return;
						}
		
						if (active.timeline.currentLabel === 'enter_end') {
							carousel.activeItemElapsedTicks++;
						} else {
							carousel.activeItemElapsedTicks = 0;
						}
		
						var maxTicks = Math.floor((settings.activeItemDuration / 1000) * createjs.Ticker.framerate);
						if (carousel.activeItemElapsedTicks === maxTicks) {
							if (active === last) carousel.completedPlaythroughs++;
							if (carousel.completedPlaythroughs - 1 === settings.repeats) {
								carousel.stop();
								Logger.timeEnd('Carousel Duration');
								return;
							}
		
							var nextId = carousel.activeItem + 1;
							if (carousel.items[nextId] === undefined) nextId = 0;
							carousel.seek(nextId);
						}
					}
				});
			};
		
			/** Stop carousel animation */
			this.stop = function () {
				if (!this.playing) return;
				this.playing = false;
				Logger.info('Carousel Stopped');
			};
		})();
		
		// Initialize asset preloader and items array
		var loader = new createjs.LoadQueue(false);
		var payload = {},
			data = [];
		
		// Prevent playing and hide canvas while assets load
		_this.visible = false;
		_this.stop();
		
		// Enable mouse over
		stage.enableMouseOver();
		
		// Preload dependencies
		loader.loadManifest([
			{ id: 'fonts', type: createjs.Types.CSS, src: 'fonts/fonts.css' },
			{ id: 'json', type: createjs.Types.JSON, src: json },
		]);
		
		// Preload images when JSON is loaded
		loader.on('fileload', function (e) {
			if (e.item.id === 'json') {
				payload = e.result;
		
				if (e.result.quantToChoose) {
					// Get number of items from JSON, if exists
					settings.maxItems = e.result.quantToChoose;
				}
				if (e.result.staticDuration) {
					// Get duration from JSON, if exists
					settings.activeItemDuration = e.result.staticDuration;
				}
				if (e.result.staticDuration) {
					// Get repeats from JSON, if exists
					settings.repeats = e.result.loops;
				}
		
				Logger.info('JSON Payload:', payload);
				Logger.info('Settings:', settings);
		
				loader.on('complete', function (e) {
					data.forEach(function (item) {
						carousel.addItem(loader.getResult('image' + item.id), item.attributes);
					});
		 
					_this.carousel.reset();
					_this.visible = true;
					_this.play();
				});
		
				var products = e.result.products;
				if (settings.maxItems > products.length) settings.maxItems = products.length;
				if (settings.randomizeItems) products = Utils.shuffle(products);
				products = products.slice(0, settings.maxItems);
				Logger.info('Selected Items:', products);
		
				loader.loadManifest(
					products.map(function (p, i) {
						// Define carousel item name and image
						var image = p.image;
						data.push({
							id: i,
							attributes: p,
							image: null,
						});
		
						var item = new createjs.LoadItem().set({
							id: 'image' + i,
							type: createjs.Types.IMAGE,
							crossOrigin: null,
							src: image,
						});
		
						return item;
					})
				);
			}
		});
		
		// Log JSON URL to console
		Logger.info('JSON URL:', json);
		
		// Export variables to window
		window.carousel = this.carousel = carousel;
		window.settings = this.settings = settings;
		window.loader = this.loader = loader;
	}
	this.frame_77 = function() {
		/**
		 * Start carousel autoplay
		 */
		
		this.carousel.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(77).call(this.frame_77).wait(53));

	// Border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EgXbgu3MAu3AAAMAAABdvMgu3AAAg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(130));

	// Logo_Container
	this.instance = new lib.Logo_Container("synched",0,false);
	this.instance.setTransform(150.1,300.4,0.8,0.8,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({regX:0.2,x:150.05,mode:"single",startPosition:71},0).to({y:52},12,cjs.Ease.quadOut).wait(65));

	// CTA
	this.instance_1 = new lib.CTA();
	this.instance_1.setTransform(0,30);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({y:0,alpha:1},12,cjs.Ease.quadOut).wait(59));

	// Carousel_Navigation
	this.carouselDots = new lib.Dots_Container();
	this.carouselDots.name = "carouselDots";
	this.carouselDots.setTransform(155,395.25,1,1,0,0,0,5,5);
	this.carouselDots._off = true;

	this.timeline.addTween(cjs.Tween.get(this.carouselDots).wait(59).to({_off:false},0).wait(71));

	// Carousel_Area
	this.carouselArea = new lib.Carousel_Container();
	this.carouselArea.name = "carouselArea";
	this.carouselArea.setTransform(100.1,215.1,1,1,0,0,0,100.1,115.1);
	this.carouselArea.alpha = 0;
	this.carouselArea._off = true;

	this.timeline.addTween(cjs.Tween.get(this.carouselArea).wait(59).to({_off:false},0).to({alpha:1},18).wait(53));

	// Background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DDC1AA").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(130));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(149,299,152,306.20000000000005);
// library properties:
lib.properties = {
	id: '242217155B264C8DB9F7399ABE3F55E5',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Carousel_Image.png?1639062063292", id:"Carousel_Image"},
		{src:"images/Logo.png?1639062063292", id:"Logo"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['242217155B264C8DB9F7399ABE3F55E5'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;